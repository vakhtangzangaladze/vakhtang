package ge.edubtu.calculator.service;

public interface CalculatorService {
}
